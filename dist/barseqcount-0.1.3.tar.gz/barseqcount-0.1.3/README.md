# barseqcount

Analysis of DNA barcode sequencing experiments

Install from PyPI:
````
pip install barseqcount
````
Full documentation: https://barseqcount.readthedocs.io/

GitHub issues (bug reports, feature requests): https://github.com/damienmarsic/barseqcount/issues/new/choose

[![brseqcount documentation](https://img.shields.io/badge/barseqcount-Documentation-yellow)](https://barseqcount.readthedocs.io/)




